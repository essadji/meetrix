export interface NotificationInterface {
    type:string;
    number:number;
}
