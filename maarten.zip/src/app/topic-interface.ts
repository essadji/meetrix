export interface TopicInterface {
    color:string;
    name:string;
    amount:number;
}