export interface MembersInfoInterface {
    number:string;
    amount:number;
}
