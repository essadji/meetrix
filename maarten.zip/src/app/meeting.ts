export interface meeting {
        date:string;
        name:string;
        topics:string;
        attendees:string[];
        commentary:string;
      }

